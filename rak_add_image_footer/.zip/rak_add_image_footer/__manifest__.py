# -*- coding: utf-8 -*-
{
    'name': "rak_add_image_footer",
    'summary': """
        Rak Add Image Footer""",
    'description': """
        Rak Add Image Footer
    """,
    'author': "",
    'website': "",
    'category': 'WEB',
    'version': '1.1.0',
    'depends': [
        'web',
    ],
    'data': [
        'report/rak_page_footer.xml',
    ],
    'installable': True,
    'application': True
}
